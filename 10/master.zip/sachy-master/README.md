# Šachy

Základ hry Šachy.

Hra potřebuje knihovnu `pyglet`, která se dá nainstalovat (s aktivním
virtuálním prostředím) pomocí:

    python -m pip install pyglet

Hru potom spustíš pomocí:

    python ui.py

Figurkama se dá hýbat, ale není hotová kontrola pravidel (kromě tahů věže).


## Licence

Tento kód a obrázky jsou k dispozici pod licencí BSD, viz soubor LICENSE.BSD.

Obrázky figur jsou z Wikipedie:
https://commons.wikimedia.org/wiki/Category:SVG_chess_pieces
